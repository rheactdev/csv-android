# Little Pages ✿

A cute, local-first CSV notebook for Android, styled as a warm pixel-art stationery book inspired by Little Chances. Each notebook is a genuine `.csv` file in an Android folder selected by the user, with page and table editors.

## Install / build APK

**The included files are source code; no APK has been compiled in this bundle.**

### Android Studio
1. Open this `little-pages` directory in Android Studio (2025.1 or newer recommended).
2. Let Android Studio download the Android SDK 35, Gradle, and Kotlin plugin.
3. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Copy the generated `app/build/outputs/apk/debug/app-debug.apk` to your Android phone and install it. You'll need to allow installs from the app that opens the APK.

### Command line with Android SDK + Gradle

With Java 17, Android SDK 35 and Gradle 8.11.1 installed:

```sh
gradle :app:assembleDebug
```

### GitHub Actions

Upload the project to your own repository, then run the included **Build Little Pages APK** workflow. Download `little-pages-debug-apk` from the completed run's Artifacts section.

## App features

- Native Android system folder picker (Storage Access Framework), persistent read/write access to a chosen directory.
- Read existing `.csv` files, create new ones, and edit their rows and columns.
- Page-style notebook view and horizontally scrollable table view.
- Autosave after 850 ms, explicit Save, conflict detection when a file changes externally.
- No accounts, servers, trackers or INTERNET permission.
- CSV parser handles commas, quotes, CRLF and multiline text.
- Android local source files use Kotlin; the interface uses offline HTML, CSS and JavaScript in a locked-down WebView.

## Browser demo

Open `app/src/main/assets/index.html` in Chrome. It uses browser localStorage with two sample notebooks. A demo can import or download CSVs, but only the Android APK accesses a user-selected Android folder.

## Notes

CSV files are treated as a column header row followed by entry rows. A plain CSV contains no information about rich field types or formatting, so the app uses text inputs (and large text areas for columns named Notes, Description, etc). Edits will normalize CSV quoting, row endings and shape when saved. The notebook preserves the values, but the original byte formatting is not preserved. Keep a backup when editing important CSV data.

Only top-level `.csv` documents in the selected folder appear. On some Android document providers, file create, overwrite and truncation behavior may vary; test against the folder provider you use. External-change detection compares contents before writing and offers conflict protection.
