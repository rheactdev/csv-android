# Little Pages ✿

A cute, local-first CSV notebook for Android, styled as a warm pixel-art stationery book inspired by Little Chances. Each notebook is a genuine `.csv` file in an Android folder selected by the user, with page and table editors.

## Install / build APK

**The included files are source code; no APK has been compiled in this bundle.**

### Android Studio
1. Open this `little-pages` directory in Android Studio (2025.1 or newer recommended).
2. Let Android Studio download the Android SDK 35, Gradle, and Kotlin plugin.
3. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Copy the generated `app/build/outputs/apk/debug/app-debug.apk` to your Android phone and install it. You'll need to allow installs from the app that opens the APK.

### Command line with Android SDK + Gradle

With Java 17, Android SDK 35 and Gradle 8.11.1 installed:

```sh
gradle :app:assembleDebug
```

### GitHub Actions

Upload the project to your own repository, then run the included **Build Little Pages APK** workflow. Download `little-pages-debug-apk` from the completed run's Artifacts section.

## Fixed in v1.1.1: image preview and duplicate imports

- Fixed the Android bitmap-size probe incorrectly interpreting a successful dimension lookup as a missing image. Existing `images/...` CSV references should display again after upgrading without reselecting photos.
- Selecting an image that is already in the notebook's `images/` directory reuses the existing relative path without creating another file. When Android returns a different URI for the same image (for example, from a gallery provider), the importer tries to match the image using file size and SHA-256 content before copying it.
- Images with spaces, parentheses, or non-English characters in their filenames can now be referenced safely in the `images/` directory.
- Selecting a different image still copies it into the notebook's `images/` folder, so you can move/backup the entire folder as one unit. You can manually clean up earlier duplicates after checking no CSV references them.

## New in v1.1: image columns

- Add a column with **+ Field / + Column**, then select **Image / Photo** as the type.
- For existing columns, choose **Fields** and switch the column type to **Image / Photo**.
- Columns such as `Image`, `Photo`, `Cover Art`, and `Screenshot` are detected automatically when there is no saved field-type preference.
- Tap **Choose image** on a page or table cell to open Android's system image picker.
- The selected image is *copied* into `images/` inside the selected notebook folder. The CSV cell stores a portable relative path, e.g. `images/image_a1b2.jpg`. The cell contains no Base64 binary.
- The column display-type preferences are stored in a `notebook.csv.littlepages.json` sidecar file beside the CSV, leaving its columns unchanged.
- Choosing **Remove** clears the CSV cell but does not delete the underlying file: the same image may be referenced elsewhere. Manage unused files with Android Files if needed.
- JPEG, PNG, WEBP, GIF, BMP, HEIC/HEIF, and AVIF can be copied (subject to Android's MIME reporting); previews require a decoder supported by the device. The per-file image limit is 25 MB.
- **Important**: Back up the whole selected folder (CSVs, `.littlepages.json` metadata, and `images/`) together if you move notebooks to another phone or sync provider.
- The browser preview uses localStorage for sample pictures and is *not* intended as a portable image backup.

### Updating an existing install

The app's version is now 1.1.1 (code 3). If Android says the updated GitHub Actions debug APK cannot be installed over an earlier build, the two builds may have different debug signing keys. You can uninstall the old app and install the new one; its files in your externally selected SAF folder should remain in place. You will need to select your notebook folder again. Back up your notebook folder first.

## App features

- Native Android system folder picker (Storage Access Framework), persistent read/write access to a chosen directory.
- Read existing `.csv` files, create new ones, and edit their rows and columns.
- Page-style notebook view and horizontally scrollable table view.
- Autosave after 850 ms, explicit Save, conflict detection when a file changes externally.
- No accounts, servers, trackers or INTERNET permission.
- CSV parser handles commas, quotes, CRLF and multiline text.
- Android local source files use Kotlin; the interface uses offline HTML, CSS and JavaScript in a locked-down WebView.

## Browser demo

Open `app/src/main/assets/index.html` in Chrome. It uses browser localStorage with two sample notebooks. A demo can import or download CSVs, but only the Android APK accesses a user-selected Android folder.

## Notes

CSV files are treated as a column header row followed by entry rows. A plain CSV contains no information about rich field types or formatting, so the app uses text inputs, larger areas for Notes/Description, and image fields configured by filename heuristics or companion metadata. Edits will normalize CSV quoting, row endings and shape when saved. The notebook preserves the values, but the original byte formatting is not preserved. Keep a backup when editing important CSV data.

Only top-level `.csv` documents in the selected folder appear. On some Android document providers, file create, overwrite and truncation behavior may vary; test against the folder provider you use. External-change detection compares contents before writing and offers conflict protection.
