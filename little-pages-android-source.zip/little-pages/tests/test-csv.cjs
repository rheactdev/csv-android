const assert = require('node:assert/strict');
require('../app/src/main/assets/csv.js');
const {parse,stringify} = globalThis.CSVCodec;
const cases = [
  [['Title','Notes'],['hello','one, two'],['"quoted"','line 1\nline 2']],
  [['a','b'],['',''],['x',''],['  spaced','yay']],
  [['name','emoji'],['cats','🐈']],
  [['header']]
];
for (const rows of cases) assert.deepEqual(parse(stringify(rows)),rows);
assert.deepEqual(parse('a,b\r\n1,2\r\n'),[['a','b'],['1','2']]);
assert.deepEqual(parse('a,b\n"x","he said ""hi"""\n'),[['a','b'],['x','he said "hi"']]);
assert.deepEqual(parse(''),[]);
assert.throws(()=>parse('"unterminated'),/unfinished/);
console.log('CSV tests passed');
