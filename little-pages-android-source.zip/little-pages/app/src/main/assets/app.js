'use strict';
const native = typeof AndroidFiles !== 'undefined';
const $ = selector => document.querySelector(selector);
const safe = value => String(value ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const JS = value => JSON.stringify(value).replace(/</g,'\\u003c');
const bookColors = ['pink','sage','lavender','beige'];
const state = {folder: null, files: [], notebook: null, page:0, view:'library', original:'', dirty:false, saving:false, conflict:false, autosave:null, notice:null};
function previewSeed(){
  if (!localStorage.getItem('lp-seeded')) {
    const seed=[
      ['book-journal.csv','Title,Author,Status,Notes\r\nThe Hobbit,J.R.R. Tolkien,Finished,"A cozy, wonderful adventure."\r\nHowl\'s Moving Castle,Diana Wynne Jones,Reading,A magical little world\r\n'],
      ['little-wishes.csv','Wish,Category,Notes\r\nVisit a bookshop,Outings,Pick out a new novel\r\nMake an apple pie,Home,Try a vintage recipe\r\n']
    ];
    for (let i=0;i<seed.length;i++)localStorage.setItem('lp-file:'+seed[i][0],seed[i][1]);
    localStorage.setItem('lp-seeded','1');
  }
}
const store = {
  folder(){if(native)return JSON.parse(AndroidFiles.getFolderInfo()); return {connected:true,name:'Sample notebook shelf · browser preview',preview:true}},
  list(){if(native)return JSON.parse(AndroidFiles.listFiles()); return Object.keys(localStorage).filter(k=>k.startsWith('lp-file:')).map(k=>({id:k.slice(8),name:k.slice(8)})).sort((a,b)=>a.name.localeCompare(b.name));},
  read(id){if(native)return JSON.parse(AndroidFiles.readFile(id));return {ok:true,text:localStorage.getItem('lp-file:'+id) || ''};},
  create(name,content){if(native)return JSON.parse(AndroidFiles.createFile(name,content)); if(localStorage.getItem('lp-file:'+name)!==null)return {ok:false,error:'A notebook with that filename already exists.'};localStorage.setItem('lp-file:'+name,content);return {ok:true,id:name,name}},
  save(id,content,expected,force){if(native)return JSON.parse(AndroidFiles.saveFile(id,content,expected,force));const key='lp-file:'+id; if(localStorage.getItem(key)!==expected&&!force)return {ok:false,conflict:true,error:'This file was changed elsewhere.'};localStorage.setItem(key,content);return {ok:true}},
  choose(){if(native)AndroidFiles.pickFolder();else showNotice('Browser preview: install the Android app to choose a local folder. You can import and export CSVs here.','warn')}
};
function showNotice(text,kind=''){state.notice={text,kind};renderNotice();}
function renderNotice(){
  const el=$('#notice');
  if(!el)return;
  el.innerHTML=state.notice?`<div class="notice ${safe(state.notice.kind)}">${safe(state.notice.text)}${state.conflict?'<div class="toolbar"><button class="btn sm ghost" onclick="reloadFile()">Reload file</button><button class="btn sm pink" onclick="overrideFile()">Overwrite file</button></div>':''}</div>`:'';
}
function loadLibrary(){state.folder=store.folder();state.files=store.list();state.view='library';state.notebook=null;render();}
window.onFolderPicked=function(ok){if(ok){state.notice=null;loadLibrary()}else showNotice('No folder selected.','warn')};
function openNotebook(id){
  if(!leaveAndSave())return;
  const file=state.files.find(f=>f.id===id);if(!file)return;
  const result=store.read(id);if(!result.ok){showNotice(result.error||'Unable to read file.','error');return}
  try{
    let rows=CSVCodec.parse(result.text);
    if(!rows.length)rows=[['Title','Notes']];
    const max=Math.max(1,...rows.map(row=>row.length));
    if(max>rows[0].length)for(let i=rows[0].length;i<max;i++)rows[0].push('Field '+(i+1));
    state.notebook={id,name:file.name,header:rows[0].map((x,i)=>x||'Field '+(i+1)),rows:rows.slice(1).map(r=>Array.from({length:max},(_,i)=>r[i]??''))};
    state.original=result.text;state.dirty=false;state.conflict=false;state.page=0;state.view='page';state.notice=null;render();
  }catch(e){showNotice('Unable to open this CSV: '+e.message,'error')}
}
function serialize(){if(!state.notebook)return '';return CSVCodec.stringify([state.notebook.header,...state.notebook.rows]);}
function markEdited(){state.dirty=serialize()!==state.original;renderStatus();clearTimeout(state.autosave);if(state.dirty&&!state.conflict)state.autosave=setTimeout(()=>saveNow(false),850)}
function saveNow(force=false){
  clearTimeout(state.autosave);
  if(!state.notebook||!state.dirty||state.saving)return true;
  state.saving=true;const text=serialize();
  try{
    const res=store.save(state.notebook.id,text,state.original,force);
    if(res.ok){state.original=text;state.dirty=false;state.conflict=false;renderStatus();return true}
    if(res.conflict){state.conflict=true;showNotice('This CSV changed outside the app. Reload it or choose "Overwrite file" to replace those changes.','warn')}
    else showNotice(res.error||'Could not save changes.','error');renderStatus();return false;
  }catch(e){showNotice('Save failed: '+e.message,'error');return false}
  finally{state.saving=false}
}
function reloadFile(){
  if(!state.notebook)return;
  if(!window.confirm('Discard your unsaved edits and load the version currently on disk?'))return;
  const id=state.notebook.id;
  state.dirty=false;state.conflict=false;openNotebook(id);
}
function overrideFile(){
  if(window.confirm('Overwrite the changes another app made to this CSV?')){
    if(saveNow(true)){state.notice=null;render()}
  }
}
function leaveAndSave(){if(!state.notebook||!state.dirty)return true;if(state.conflict){return window.confirm('You have unsaved changes because the file changed elsewhere. Leave and lose your edits?')}
  if(saveNow())return true;return window.confirm('Your edits could not be saved. Leave and lose your edits?')}
function changeView(view){if(view==='library'){if(!leaveAndSave())return;loadLibrary();return}if(!state.notebook)return;if(view===state.view)return;state.view=view;render();}
function renderTabs(){let html='<button class="tab '+(state.view==='library'?'active':'')+'" onclick="changeView(\'library\')">⌂ library</button>';if(state.notebook){html+='<button class="tab '+(state.view==='page'?'active':'')+'" onclick="changeView(\'page\')">▤ pages</button><button class="tab '+(state.view==='table'?'active':'')+'" onclick="changeView(\'table\')">▦ table</button>'}$('#tabs').innerHTML=html}
function render(){renderTabs();if(state.view==='library')renderLibrary();else if(state.view==='page')renderPage();else renderTable();renderNotice();}
function renderLibrary(){
  const folder=state.folder||{connected:false};
  const label=folder.connected?folder.name:'no folder chosen yet';
  let html=`<div class="eyebrow">✦ your little collection</div><div class="row between"><h2 class="title">Notebook shelf</h2><button class="btn sm primary" onclick="newBook()">＋ New</button></div><p class="intro">Each tiny notebook is a real CSV file, ready to write in whenever you like.</p><div class="folder-strip"><span>▣</span><span class="path">${safe(label)}</span><button onclick="store.choose()">${folder.connected?'CHANGE':'CHOOSE'}</button></div><div id="notice"></div>`;
  if(!folder.connected){html+=`<div class="empty"><img src="cat.png" alt="Cat with notebook"><h2>Your shelf is empty</h2><p>Choose a folder on your phone to keep all your little CSV notebooks together.</p><button class="btn primary" onclick="store.choose()">▣ choose a folder</button></div>`}
  else{
    html+='<div class="divider">✿ notebooks</div><div class="books">';
    state.files.forEach((f,i)=>{let name=f.name.replace(/\.csv$/i,'').replace(/[_-]/g,' ');let color=bookColors[i%bookColors.length];html+=`<button class="book-button" onclick="openNotebook(${safe(JS(f.id))})"><div class="cover ${color}"><img class="stamp" src="${i%2?'flower.png':'cat.png'}" alt=""><div class="cover-title">${safe(name)}</div><div class="cover-small">a little notebook</div></div><span class="book-meta"><strong>${safe(name)}</strong><small>${safe(f.name)}</small></span></button>`});
    html+=`<button class="book-button" onclick="newBook()"><div class="cover new-cover"><span>＋</span><strong>new notebook</strong></div><span class="book-meta"><strong>Start a new one...</strong><small>create a CSV</small></span></button></div>`;
    if(!native)html+='<div style="margin-top:26px" class="toolbar"><button class="btn sm ghost" onclick="$(\'#import-file\').click()">↑ Import CSV</button><span class="note">Preview saves in your browser. Android saves directly to your chosen folder.</span></div>';
  }
  html+='<p class="note" style="margin-top:25px">✦ Just your files, your words, your little corner of the world.</p>';
  $('#app').innerHTML=html;
}
function renderPage(){
  const n=state.notebook;const count=n.rows.length;state.page=Math.max(0,Math.min(state.page,Math.max(0,count-1)));
  const item=n.rows[state.page]||Array.from({length:n.header.length},()=>''),title=item[0]||'An untitled page';
  let html=`<div class="booktop"><button class="back" onclick="changeView('library')">‹ all notebooks</button><span class="eyebrow">✦ ${safe(n.name)}</span></div><div class="row between" style="margin-top:9px"><h2 class="title">${safe(n.name.replace(/\.csv$/i,'').replace(/[_-]/g,' '))}</h2><button class="btn sm ghost" onclick="changeView('table')">▦ table</button></div><div id="notice"></div>`;
  if(!count){html+=`<div class="empty"><img src="flower.png" alt="Pixel flower"><h2>A blank little page</h2><p>There's nothing written here yet.</p><button class="btn primary" onclick="addPage()">＋ Add first entry</button></div>`}
  else{
    html+=`<div class="notebook"><div class="paper-head"><div class="eyebrow">✿ page ${state.page+1} of ${count} ✿</div><h2>${safe(title)}</h2><small>✧ ${safe(n.name)} ✧</small></div><div class="formfields">`;
    n.header.forEach((field,i)=>{const val=item[i]??'';const multiline=/note|description|content|journal|detail|thought|review/i.test(field)||val.includes('\n');html+=`<div class="field"><label class="field-label" for="field-${i}">${safe(field)}</label>${multiline?`<textarea class="input multi" id="field-${i}" data-field="${i}" oninput="editField(this)" rows="4">${safe(val)}</textarea>`:`<input class="input" type="text" id="field-${i}" data-field="${i}" oninput="editField(this)" value="${safe(val)}"/>`}</div>`});
    html+=`</div></div><div class="notebook-controls"><button class="btn sm ghost" onclick="flip(-1)" ${state.page===0?'disabled':''}>← prev</button><span class="pagination">${state.page+1} / ${count}</span><button class="btn sm ghost" onclick="flip(1)" ${state.page>=count-1?'disabled':''}>next →</button></div>`;
  }
  html+=`<div class="toolbar"><button class="btn primary" onclick="addPage()">＋ New entry</button><button class="btn" onclick="saveNow()">▣ Save</button><button class="btn ghost sm" onclick="addColumn()">＋ Field</button>${count?'<button class="btn ghost sm" onclick="deleteEntry()">− Entry</button>':''}${!native?'<button class="btn ghost sm" onclick="exportCSV()">↓ CSV</button>':''}</div><div id="save-status" class="status"></div>`;
  $('#app').innerHTML=html;renderStatus();
}
function editField(el){const i=Number(el.dataset.field);state.notebook.rows[state.page][i]=el.value;if(i===0){const heading=$('.paper-head h2');if(heading)heading.textContent=el.value||'An untitled page'}markEdited()}
function flip(delta){saveNow();state.page=Math.max(0,Math.min(state.notebook.rows.length-1,state.page+delta));render()}
function addPage(){const n=state.notebook;n.rows.push(n.header.map(()=>''));state.page=n.rows.length-1;markEdited();state.view='page';render();setTimeout(()=>$('#field-0')?.focus(),20)}
function deleteEntry(){if(!window.confirm('Remove this entry from the CSV?'))return;state.notebook.rows.splice(state.page,1);state.page=Math.max(0,state.page-1);markEdited();render()}
function addColumn(){modal('Add a field',`<p>A new column will be added to your CSV.</p><div class="field"><label class="field-label">Field name</label><input class="input" id="new-field" placeholder="e.g. Category" maxlength="100"></div>`,`<button class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn primary" onclick="confirmColumn()">Add field</button>`)}
function confirmColumn(){let name=$('#new-field').value.trim();if(!name)return alert('Enter a field name.');state.notebook.header.push(name);state.notebook.rows.forEach(r=>r.push(''));closeModal();markEdited();render()}
function renderTable(){
 const n=state.notebook;let html=`<div class="booktop"><button class="back" onclick="changeView('library')">‹ all notebooks</button><span class="eyebrow">✦ table view</span></div><h2 class="title">${safe(n.name)}</h2><p class="intro">Edit cells directly. Swipe sideways to see more columns.</p><div id="notice"></div><div class="table-wrap"><table class="grid-table"><thead><tr><th>#</th>`;
 n.header.forEach((h)=>html+='<th>'+safe(h)+'</th>');html+='</tr></thead><tbody>';
 n.rows.forEach((row,r)=>{
   html+=`<tr><td>${r+1}</td>`;
   n.header.forEach((_,c)=>{
     const val=row[c]??'';
     html+=val.includes('\n')?`<td><textarea class="input" style="min-width:140px;min-height:72px" aria-label="row ${r+1} ${safe(n.header[c])}" data-row="${r}" data-col="${c}" oninput="editCell(this)">${safe(val)}</textarea></td>`:`<td><input aria-label="row ${r+1} ${safe(n.header[c])}" value="${safe(val)}" data-row="${r}" data-col="${c}" oninput="editCell(this)"></td>`;
   });html+='</tr>';
 });
 html+=`</tbody></table></div><div class="toolbar"><button class="btn primary" onclick="addPage()">＋ New row</button><button class="btn" onclick="saveNow()">▣ Save</button><button class="btn ghost sm" onclick="addColumn()">＋ Column</button><button class="btn ghost sm" onclick="changeView('page')">▤ Pages</button>${!native?'<button class="btn ghost sm" onclick="exportCSV()">↓ CSV</button>':''}</div><div id="save-status" class="status"></div>`;$('#app').innerHTML=html;renderStatus();
}
function editCell(el){state.notebook.rows[Number(el.dataset.row)][Number(el.dataset.col)]=el.value;markEdited()}
function renderStatus(){let el=$('#save-status');if(!el)return;el.className='status'+(state.dirty?' dirty':'');el.textContent=state.conflict?'⚠ External changes detected · open the warning above':state.dirty?'✎ Unsaved changes · autosaving...':'✓ All changes saved to '+(native?'your CSV file':'browser preview')}
function modal(title,body,actions){$('#modal-root').innerHTML=`<div class="overlay" onclick="if(event.target===this)closeModal()"><section role="dialog" aria-modal="true" aria-label="${safe(title)}" class="modal"><div class="eyebrow">✦ little pages</div><h3>${safe(title)}</h3>${body}<div class="modal-actions">${actions}</div></section></div>`}
function closeModal(){$('#modal-root').innerHTML=''}
function newBook(){if(!state.folder?.connected){store.choose();return}modal('A fresh little notebook',`<p>Give it a name and decide which fields each page should have.</p><div class="field"><label class="field-label">Notebook name</label><input class="input" id="new-name" maxlength="80" placeholder="e.g. reading journal"></div><div class="field"><label class="field-label">Fields (separated by commas)</label><input class="input" id="new-columns" value="Title, Notes"></div>`,`<button class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn primary" onclick="createBook()">✿ Create</button>`)}
function createBook(){
  let name=$('#new-name').value.trim();let fields=$('#new-columns').value.split(',').map(x=>x.trim()).filter(Boolean);
  if(!name)return alert('Please name your notebook.');if(fields.length===0)return alert('Add at least one field.');
  name=name.replace(/[\\/:*?"<>|\x00-\x1f]/g,'-').replace(/\.csv$/i,'').trim();if(!name)return alert('Choose a different name.');
  let file=name+'.csv';const content=CSVCodec.stringify([fields]);let result=store.create(file,content);
  if(!result.ok)return alert(result.error||'Could not create the CSV.');closeModal();state.files=store.list();openNotebook(result.id||state.files.find(x=>x.name===file)?.id);
}
function exportCSV(){if(!state.notebook)return;const data=new Blob([serialize()],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(data),a=document.createElement('a');a.href=url;a.download=state.notebook.name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000)}
$('#import-file').addEventListener('change',async e=>{for(const f of e.target.files){if(!f.name.toLowerCase().endsWith('.csv'))continue;const content=await f.text();try{CSVCodec.parse(content);const res=store.create(f.name,content);if(!res.ok)alert(res.error||'Unable to import.')}catch(err){alert(err.message)}}e.target.value='';loadLibrary()});
window.addEventListener('beforeunload',e=>{if(state.dirty&&!saveNow()){e.preventDefault();e.returnValue=''}});
window.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();saveNow()}if(e.key==='Escape')closeModal()});
if(!native)previewSeed();loadLibrary();

window.requestBack=function(){if(state.notebook){changeView('library');return true;}return false;};
