(function (root) {
  'use strict';
  function parse(text) {
    if (!text || text.length === 0) return [];
    text = text.replace(/^\uFEFF/, '');
    const rows = [];
    let row = [], field = '', quoted = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (quoted) {
        if (c === '"') {
          if (text[i + 1] === '"') { field += '"'; i++; }
          else quoted = false;
        } else field += c;
      } else if (c === '"' && field === '') quoted = true;
      else if (c === ',') { row.push(field); field = ''; }
      else if (c === '\r' || c === '\n') {
        if (c === '\r' && text[i + 1] === '\n') i++;
        row.push(field); rows.push(row); row = []; field = '';
      } else field += c;
    }
    if (quoted) throw Error('The CSV contains an unfinished quoted value.');
    if (field !== '' || row.length) { row.push(field); rows.push(row); }
    return rows;
  }
  function stringify(rows) {
    return rows.map(row => row.map(value => {
      const str = String(value ?? '');
      return /[",\r\n]/.test(str) || /^\s|\s$/.test(str) ? '"' + str.replace(/"/g, '""') + '"' : str;
    }).join(',')).join('\r\n') + (rows.length ? '\r\n' : '');
  }
  root.CSVCodec = { parse, stringify };
})(typeof window === 'undefined' ? globalThis : window);
