package dev.littlepages.notebook

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.FileNotFoundException
import java.nio.charset.StandardCharsets

/** A local-only WebView shell around the pixel notebook interface.
 * CSV content lives exclusively inside the user-selected SAF document tree.
 */
class MainActivity : Activity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("little_pages", MODE_PRIVATE) }
    private val folderKey = "folder_uri"
    private val chooseFolderCode = 717
    private var selectedTree: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(247, 237, 219)
        window.navigationBarColor = Color.rgb(241, 231, 216)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        selectedTree = prefs.getString(folderKey, null)?.let(Uri::parse)
        web = WebView(this)
        web.setBackgroundColor(Color.rgb(251, 243, 231))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        @Suppress("DEPRECATION")
        web.settings.allowFileAccessFromFileURLs = false
        @Suppress("DEPRECATION")
        web.settings.allowUniversalAccessFromFileURLs = false
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean {
                return request.url.scheme != "file" || request.url.path?.startsWith("/android_asset/") != true
            }
            @Deprecated("Legacy navigation guard")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean =
                !url.startsWith("file:///android_asset/")
        }
        // The bridge must only be available to app-owned bundled HTML, never to outside sites.
        web.addJavascriptInterface(FileBridge(), "AndroidFiles")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onDestroy() {
        web.removeJavascriptInterface("AndroidFiles")
        web.destroy()
        super.onDestroy()
    }

    @Deprecated("Uses Activity results for compatibility without additional AndroidX dependencies")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != chooseFolderCode) return
        var granted = false
        if (resultCode == RESULT_OK && data?.data != null) {
            val uri = data.data!!
            try {
                val takeFlags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                contentResolver.takePersistableUriPermission(uri, takeFlags)
                selectedTree = uri
                prefs.edit().putString(folderKey, uri.toString()).apply()
                granted = true
            } catch (_: Exception) { granted = false }
        }
        web.evaluateJavascript("window.onFolderPicked(${if (granted) "true" else "false"})", null)
    }

    @Deprecated("Classic back handler for the single-activity WebView")
    override fun onBackPressed() {
        web.evaluateJavascript("window.requestBack()") { result ->
            if (result == "false") finish()
        }
    }

    private fun checkTree(): Uri {
        val tree = selectedTree ?: throw FileNotFoundException("Choose a folder first.")
        val persisted = contentResolver.persistedUriPermissions.any { it.uri == tree && it.isReadPermission && it.isWritePermission }
        if (!persisted) throw SecurityException("Folder permission expired. Choose the folder again.")
        return tree
    }

    private fun docUri(id: String): Uri {
        val tree = checkTree()
        // Document IDs may be opaque (some providers do not use hierarchical IDs).
        // Verify against the current direct children rather than checking an ID prefix.
        val files = JSONArray(FileBridge().listFiles())
        var allowed = false
        for (i in 0 until files.length()) {
            if (files.getJSONObject(i).optString("id") == id) { allowed = true; break }
        }
        if (!allowed) throw SecurityException("Document is outside the selected folder.")
        return DocumentsContract.buildDocumentUriUsingTree(tree, id)
    }

    private fun readText(id: String): String =
        contentResolver.openInputStream(docUri(id))?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() }
            ?: throw FileNotFoundException("Couldn't read the CSV.")

    private fun success(data: JSONObject = JSONObject()): String = data.put("ok", true).toString()
    private fun fail(error: Throwable): String = JSONObject().put("ok", false)
        .put("error", error.message ?: "File operation failed.").toString()

    inner class FileBridge {
        @JavascriptInterface
        fun pickFolder() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
                }
                @Suppress("DEPRECATION")
                startActivityForResult(intent, chooseFolderCode)
            }
        }

        @JavascriptInterface
        fun getFolderInfo(): String {
            return try {
                val tree = checkTree()
                val id = DocumentsContract.getTreeDocumentId(tree)
                val root = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                var name = "Your notebook folder"
                contentResolver.query(root, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) name = c.getString(0)
                }
                JSONObject().put("connected", true).put("name", name).toString()
            } catch (_: Exception) { JSONObject().put("connected", false).toString() }
        }

        @JavascriptInterface
        fun listFiles(): String {
            val result = JSONArray()
            try {
                val tree = checkTree()
                val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
                val projection = arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE)
                contentResolver.query(children, projection, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getString(0)
                        val name = c.getString(1) ?: continue
                        val mime = c.getString(2)
                        if (name.endsWith(".csv", ignoreCase = true) && mime != DocumentsContract.Document.MIME_TYPE_DIR) {
                            result.put(JSONObject().put("id", id).put("name", name))
                        }
                    }
                }
            } catch (_: Exception) { }
            val list = (0 until result.length()).map { result.getJSONObject(it) }.sortedBy { it.optString("name").lowercase() }
            return JSONArray(list).toString()
        }

        @JavascriptInterface
        fun readFile(id: String): String = try { success(JSONObject().put("text", readText(id))) }
        catch (e: Exception) { fail(e) }

        @JavascriptInterface
        fun createFile(name: String, contents: String): String {
            return try {
                require(Regex("^[^\\\\/:*?\"<>|\\u0000-\\u001F]{1,100}\\.csv$", RegexOption.IGNORE_CASE).matches(name)) { "Invalid CSV filename." }
                val tree = checkTree()
                val folder = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
                // Avoid silently creating name (1).csv or replacing an existing file.
                val existing = JSONArray(listFiles())
                for (i in 0 until existing.length()) {
                    if (existing.getJSONObject(i).getString("name").equals(name, ignoreCase = true))
                        return JSONObject().put("ok", false).put("error", "A notebook with that name exists.").toString()
                }
                val uri = DocumentsContract.createDocument(contentResolver, folder, "text/csv", name)
                    ?: throw FileNotFoundException("Couldn't create the file.")
                try {
                    contentResolver.openOutputStream(uri, "wt")?.use { it.write(contents.toByteArray(StandardCharsets.UTF_8)) }
                        ?: throw FileNotFoundException("Can't write to the new file.")
                } catch (e: Exception) {
                    DocumentsContract.deleteDocument(contentResolver, uri)
                    throw e
                }
                success(JSONObject().put("id", DocumentsContract.getDocumentId(uri)).put("name", name))
            } catch (e: Exception) { fail(e) }
        }

        @JavascriptInterface
        fun saveFile(id: String, contents: String, expected: String, force: Boolean): String {
            return try {
                val before = readText(id)
                if (before != expected && !force)
                    JSONObject().put("ok", false).put("conflict", true)
                        .put("error", "File changed in another app.").toString()
                else {
                    contentResolver.openOutputStream(docUri(id), "rwt")?.use { it.write(contents.toByteArray(StandardCharsets.UTF_8)) }
                        ?: throw FileNotFoundException("Couldn't write the CSV.")
                    success()
                }
            } catch (e: Exception) { fail(e) }
        }
    }
}
