package dev.littlepages.notebook

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.FileNotFoundException
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.UUID

/** Offline pixel-notebook interface. CSVs, field types and pictures live under a chosen SAF folder. */
class MainActivity : Activity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("little_pages", MODE_PRIVATE) }
    private val folderKey = "folder_uri"
    private val chooseFolderCode = 717
    private val chooseImageCode = 718
    private var selectedTree: Uri? = null
    private data class PendingImage(val notebookId: String, val row: Int, val column: Int)
    private var pendingImage: PendingImage? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(247, 237, 219)
        window.navigationBarColor = Color.rgb(241, 231, 216)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        selectedTree = prefs.getString(folderKey, null)?.let(Uri::parse)
        web = WebView(this)
        web.setBackgroundColor(Color.rgb(251, 243, 231))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        @Suppress("DEPRECATION")
        web.settings.allowFileAccessFromFileURLs = false
        @Suppress("DEPRECATION")
        web.settings.allowUniversalAccessFromFileURLs = false
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean {
                return request.url.scheme != "file" || request.url.path?.startsWith("/android_asset/") != true
            }
            @Deprecated("Legacy navigation guard")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean =
                !url.startsWith("file:///android_asset/")
        }
        web.addJavascriptInterface(FileBridge(), "AndroidFiles")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onDestroy() {
        web.removeJavascriptInterface("AndroidFiles")
        web.destroy()
        super.onDestroy()
    }

    @Deprecated("Uses Activity results for compatibility without additional AndroidX dependencies")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == chooseFolderCode) {
            var granted = false
            if (resultCode == RESULT_OK && data?.data != null) {
                val uri = data.data!!
                try {
                    val takeFlags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    contentResolver.takePersistableUriPermission(uri, takeFlags)
                    selectedTree = uri
                    prefs.edit().putString(folderKey, uri.toString()).apply()
                    granted = true
                } catch (_: Exception) { granted = false }
            }
            web.evaluateJavascript("window.onFolderPicked(${if (granted) "true" else "false"})", null)
            return
        }
        if (requestCode == chooseImageCode) {
            val target = pendingImage ?: return
            pendingImage = null
            val result = try {
                if (resultCode == RESULT_OK && data?.data != null) {
                    csvUri(target.notebookId) // Recheck selected folder after returning from the picker.
                    // The selected image is copied immediately; no long-lived read permission is required.
                    success(JSONObject().put("path", copyImageToFolder(data.data!!)))
                } else fail(IllegalStateException("Image selection canceled."))
            } catch (e: Exception) { fail(e) }
            // JSONObject.quote handles opaque Android document IDs safely inside the JS expression.
            val script = "window.onImagePicked(${JSONObject.quote(target.notebookId)},${target.row},${target.column},$result)"
            web.evaluateJavascript(script, null)
        }
    }

    @Deprecated("Classic back handler for the single-activity WebView")
    override fun onBackPressed() {
        web.evaluateJavascript("window.requestBack()") { result ->
            if (result == "false") finish()
        }
    }

    private fun checkTree(): Uri {
        val tree = selectedTree ?: throw FileNotFoundException("Choose a folder first.")
        val persisted = contentResolver.persistedUriPermissions.any { it.uri == tree && it.isReadPermission && it.isWritePermission }
        if (!persisted) throw SecurityException("Folder permission expired. Choose the folder again.")
        return tree
    }

    private fun rootUri(): Uri {
        val tree = checkTree()
        return DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
    }

    private fun childrenOf(parent: Uri): List<Triple<String, String, String>> {
        val tree = checkTree()
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getDocumentId(parent))
        val result = mutableListOf<Triple<String, String, String>>()
        contentResolver.query(children, arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        ), null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(1) ?: continue
                result.add(Triple(c.getString(0), name, c.getString(2) ?: ""))
            }
        }
        return result
    }

    private fun child(parent: Uri, name: String): Uri? {
        val tree = checkTree()
        val entry = childrenOf(parent).firstOrNull { it.second == name } ?: return null
        return DocumentsContract.buildDocumentUriUsingTree(tree, entry.first)
    }

    private fun csvUri(id: String): Uri {
        val tree = checkTree()
        val entry = childrenOf(rootUri()).firstOrNull {
            it.first == id && it.second.endsWith(".csv", true) && it.third != DocumentsContract.Document.MIME_TYPE_DIR
        } ?: throw SecurityException("CSV is outside the selected folder.")
        return DocumentsContract.buildDocumentUriUsingTree(tree, entry.first)
    }

    private fun csvName(id: String): String = childrenOf(rootUri()).firstOrNull {
        it.first == id && it.second.endsWith(".csv", true) && it.third != DocumentsContract.Document.MIME_TYPE_DIR
    }?.second ?: throw FileNotFoundException("Notebook not found.")

    private fun readString(uri: Uri): String =
        contentResolver.openInputStream(uri)?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() }
            ?: throw FileNotFoundException("Couldn't read the document.")

    private fun writeString(uri: Uri, data: String) {
        contentResolver.openOutputStream(uri, "rwt")?.use { it.write(data.toByteArray(StandardCharsets.UTF_8)) }
            ?: throw FileNotFoundException("Couldn't write to the document.")
    }

    private fun success(data: JSONObject = JSONObject()): String = data.put("ok", true).toString()
    private fun fail(error: Throwable): String = JSONObject().put("ok", false)
        .put("error", error.message ?: "File operation failed.").toString()

    private fun metadataName(id: String) = csvName(id) + ".littlepages.json"

    /** CSVs store only filenames inside the selected tree, never external URLs or absolute paths. */
    private fun safeImageName(name: String): Boolean = name.isNotEmpty() && name.length <= 240 &&
        name != "." && name != ".." && !name.contains('/') && !name.contains('\\') &&
        name.none { it.code < 32 || it.code == 127 }

    private fun resolveImage(path: String): Uri {
        require(path.length <= 256 && !path.contains('\\')) { "Invalid image path." }
        val parts = path.split('/')
        require(parts.size in 1..2 && safeImageName(parts.last())) { "Invalid image path." }
        val root = rootUri()
        val folder = if (parts.size == 2) {
            require(parts[0] == "images") { "Only images inside your notebook folder can be opened." }
            child(root, "images") ?: throw FileNotFoundException("The images folder is missing.")
        } else root
        val image = child(folder, parts.last()) ?: throw FileNotFoundException("This image is missing.")
        val mime = contentResolver.getType(image) ?: ""
        require(mime.startsWith("image/") || parts.last().contains(Regex("(?i)\\.(png|jpe?g|webp|gif|heic|heif|avif|bmp)$"))) { "This file isn't an image." }
        return image
    }

    private fun imagePreview(path: String): String {
        val uri = resolveImage(path)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        // inJustDecodeBounds *always* makes decodeStream return null; the dimensions
        // are populated on the Options object. Never test that null as a read failure.
        val boundsStream = contentResolver.openInputStream(uri)
            ?: throw FileNotFoundException("Couldn't read the image.")
        boundsStream.use { BitmapFactory.decodeStream(it, null, bounds) }
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Image format isn't supported for preview." }
        var sample = 1
        while (bounds.outWidth / sample > 800 || bounds.outHeight / sample > 800) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
            ?: throw FileNotFoundException("Couldn't decode this image.")
        return try {
            // Preserve transparency for artwork, compress photographs as JPEG.
            val alpha = bitmap.hasAlpha()
            val output = ByteArrayOutputStream()
            bitmap.compress(if (alpha) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG,
                if (alpha) 100 else 82, output)
            val mime = if (alpha) "image/png" else "image/jpeg"
            "data:$mime;base64," + Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
        } finally { bitmap.recycle() }
    }

    private data class ImageEntry(val id: String, val name: String, val size: Long?)

    /** One query for candidate files so selecting a gallery URI doesn't copy a duplicate. */
    private fun existingImages(folder: Uri): List<ImageEntry> {
        val tree = checkTree()
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getDocumentId(folder))
        val files = mutableListOf<ImageEntry>()
        try {
            contentResolver.query(childrenUri, arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE
            ), null, null, null)?.use { cursor ->
                while (cursor.moveToNext()) {
                    val name = cursor.getString(1) ?: continue
                    val mime = cursor.getString(2) ?: ""
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR || !safeImageName(name)) continue
                    if (!mime.startsWith("image/") && !name.contains(Regex("(?i)\\.(png|jpe?g|webp|gif|heic|heif|avif|bmp)$"))) continue
                    val size = if (cursor.isNull(3)) null else cursor.getLong(3).takeIf { it > 0 }
                    files.add(ImageEntry(cursor.getString(0), name, size))
                }
            }
        } catch (_: Exception) {
            // Some third-party SAF providers don't support the optional SIZE column.
            files.clear()
            for ((id, name, mime) in childrenOf(folder)) {
                if (safeImageName(name) && mime != DocumentsContract.Document.MIME_TYPE_DIR &&
                    (mime.startsWith("image/") || name.contains(Regex("(?i)\\.(png|jpe?g|webp|gif|heic|heif|avif|bmp)$")))) {
                    files.add(ImageEntry(id, name, null))
                }
            }
        }
        return files
    }

    private fun selectedSize(uri: Uri): Long? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst() && !cursor.isNull(0)) cursor.getLong(0).takeIf { it > 0 }
            else null
        }
    } catch (_: Exception) { null }

    private fun imageDigest(uri: Uri): ByteArray {
        val digest = MessageDigest.getInstance("SHA-256")
        val input = contentResolver.openInputStream(uri) ?: throw FileNotFoundException("Couldn't read selected image.")
        input.use { stream ->
            val buffer = ByteArray(64 * 1024)
            var total = 0L
            while (true) {
                val n = stream.read(buffer)
                if (n == -1) break
                total += n
                require(total <= 25L * 1024 * 1024) { "Please choose an image smaller than 25 MB." }
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest()
    }

    private fun reusableImage(selected: Uri, folder: Uri): String? {
        val entries = existingImages(folder)
        // DocumentsContract uses the same document ID for a file selected in the picker
        // and enumerated under the notebook's images/ tree (when the provider matches).
        if (selected.authority == folder.authority && DocumentsContract.isDocumentUri(this, selected)) {
            val selectedId = try { DocumentsContract.getDocumentId(selected) } catch (_: Exception) { null }
            entries.firstOrNull { it.id == selectedId }?.let { return "images/${it.name}" }
        }
        // A gallery/media provider might expose that very same file with a different
        // URI. Compare size first and then SHA-256 to avoid needless second copies.
        if (entries.isEmpty()) return null
        val size = selectedSize(selected)
        if (size != null && size > 25L * 1024 * 1024) throw IllegalArgumentException("Please choose an image smaller than 25 MB.")
        val candidates = entries.filter { it.size == null || size == null || it.size == size }
        if (candidates.isEmpty()) return null
        val selectedHash = imageDigest(selected)
        val tree = checkTree()
        for (item in candidates) {
            try {
                val candidateUri = DocumentsContract.buildDocumentUriUsingTree(tree, item.id)
                if (selectedHash.contentEquals(imageDigest(candidateUri))) return "images/${item.name}"
            } catch (_: Exception) { /* Unreadable/oversized existing file: keep looking. */ }
        }
        return null
    }

    private fun copyImageToFolder(selected: Uri): String {
        checkTree()
        val mime = contentResolver.getType(selected) ?: ""
        require(mime.startsWith("image/")) { "Choose an image file." }
        val ext = when (mime.lowercase()) {
            "image/jpeg", "image/jpg" -> "jpg"
            "image/png" -> "png"
            "image/webp" -> "webp"
            "image/gif" -> "gif"
            "image/heic" -> "heic"
            "image/heif" -> "heif"
            "image/avif" -> "avif"
            "image/bmp" -> "bmp"
            else -> throw IllegalArgumentException("This image format isn't supported yet.")
        }
        val root = rootUri()
        val images = child(root, "images") ?: DocumentsContract.createDocument(contentResolver, root,
            DocumentsContract.Document.MIME_TYPE_DIR, "images")
            ?: throw FileNotFoundException("Couldn't make the images folder.")
        // Reuse an already imported image instead of copying it again.
        reusableImage(selected, images)?.let { return it }
        val name = "image_${UUID.randomUUID().toString().replace("-", "").take(16)}.$ext"
        val dest = DocumentsContract.createDocument(contentResolver, images, mime, name)
            ?: throw FileNotFoundException("Couldn't create an image file.")
        try {
            val input = contentResolver.openInputStream(selected) ?: throw FileNotFoundException("Couldn't open selected image.")
            input.use { source ->
                val output = contentResolver.openOutputStream(dest, "wt") ?: throw FileNotFoundException("Couldn't save image.")
                output.use { out ->
                    val buf = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val n = source.read(buf)
                        if (n == -1) break
                        total += n
                        require(total <= 25L * 1024 * 1024) { "Please choose an image smaller than 25 MB." }
                        out.write(buf, 0, n)
                    }
                }
            }
        } catch (e: Exception) {
            try { DocumentsContract.deleteDocument(contentResolver, dest) } catch (_: Exception) { }
            throw e
        }
        // Resolve the actual display name. Some providers alter filenames at creation.
        val finalName = childrenOf(images).firstOrNull { it.first == DocumentsContract.getDocumentId(dest) }?.second ?: name
        return "images/$finalName"
    }

    inner class FileBridge {
        @JavascriptInterface
        fun pickFolder() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
                }
                @Suppress("DEPRECATION")
                startActivityForResult(intent, chooseFolderCode)
            }
        }

        @JavascriptInterface
        fun pickImage(notebookId: String, row: Int, column: Int) {
            runOnUiThread {
                try {
                    csvUri(notebookId) // Prevent stale or out-of-folder source IDs.
                    require(row >= 0 && column >= 0)
                    pendingImage = PendingImage(notebookId, row, column)
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "image/*"
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    @Suppress("DEPRECATION")
                    startActivityForResult(intent, chooseImageCode)
                } catch (e: Exception) {
                    val error = fail(e)
                    web.evaluateJavascript("window.onImagePicked(${JSONObject.quote(notebookId)},$row,$column,$error)", null)
                }
            }
        }

        @JavascriptInterface
        fun readImage(path: String): String = try { success(JSONObject().put("data", imagePreview(path))) }
            catch (e: Exception) { fail(e) }

        @JavascriptInterface
        fun readFieldTypes(id: String): String = try {
            csvUri(id)
            val metadata = child(rootUri(), metadataName(id))
            if (metadata == null) success(JSONObject().put("types", JSONArray()))
            else success(JSONObject().put("types", JSONObject(readString(metadata)).optJSONArray("types") ?: JSONArray()))
        } catch (e: Exception) { fail(e) }

        @JavascriptInterface
        fun saveFieldTypes(id: String, typesJson: String): String = try {
            csvUri(id)
            val types = JSONArray(typesJson)
            require(types.length() <= 500) { "Too many fields." }
            for (i in 0 until types.length()) {
                require(types.getString(i) == "text" || types.getString(i) == "image") { "Invalid field type." }
            }
            val name = metadataName(id)
            val metadata = child(rootUri(), name) ?: DocumentsContract.createDocument(contentResolver,
                rootUri(), "application/json", name) ?: throw FileNotFoundException("Couldn't create field settings.")
            writeString(metadata, JSONObject().put("version", 1).put("types", types).toString())
            success()
        } catch (e: Exception) { fail(e) }

        @JavascriptInterface
        fun getFolderInfo(): String {
            return try {
                val root = rootUri()
                var name = "Your notebook folder"
                contentResolver.query(root, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) name = c.getString(0)
                }
                JSONObject().put("connected", true).put("name", name).toString()
            } catch (_: Exception) { JSONObject().put("connected", false).toString() }
        }

        @JavascriptInterface
        fun listFiles(): String {
            val result = JSONArray()
            try {
                for ((id, name, mime) in childrenOf(rootUri())) {
                    if (name.endsWith(".csv", ignoreCase = true) && mime != DocumentsContract.Document.MIME_TYPE_DIR)
                        result.put(JSONObject().put("id", id).put("name", name))
                }
            } catch (_: Exception) { }
            val list = (0 until result.length()).map { result.getJSONObject(it) }.sortedBy { it.optString("name").lowercase() }
            return JSONArray(list).toString()
        }

        @JavascriptInterface
        fun readFile(id: String): String = try { success(JSONObject().put("text", readString(csvUri(id)))) }
            catch (e: Exception) { fail(e) }

        @JavascriptInterface
        fun createFile(name: String, contents: String): String {
            return try {
                require(Regex("^[^\\\\/:*?\"<>|\\u0000-\\u001F]{1,100}\\.csv$", RegexOption.IGNORE_CASE).matches(name)) { "Invalid CSV filename." }
                val root = rootUri()
                if (childrenOf(root).any { it.second.equals(name, ignoreCase = true) })
                    return JSONObject().put("ok", false).put("error", "A notebook with that name exists.").toString()
                val uri = DocumentsContract.createDocument(contentResolver, root, "text/csv", name)
                    ?: throw FileNotFoundException("Couldn't create the file.")
                try { writeString(uri, contents) }
                catch (e: Exception) { DocumentsContract.deleteDocument(contentResolver, uri); throw e }
                success(JSONObject().put("id", DocumentsContract.getDocumentId(uri)).put("name", name))
            } catch (e: Exception) { fail(e) }
        }

        @JavascriptInterface
        fun saveFile(id: String, contents: String, expected: String, force: Boolean): String {
            return try {
                val uri = csvUri(id)
                val before = readString(uri)
                if (before != expected && !force)
                    JSONObject().put("ok", false).put("conflict", true)
                        .put("error", "File changed in another app.").toString()
                else { writeString(uri, contents); success() }
            } catch (e: Exception) { fail(e) }
        }
    }
}
